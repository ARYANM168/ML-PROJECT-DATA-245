# Part 3: Day-type clustering and scheduling benefit

## Setup
1. Put `caiso_hourly.csv` (the shared target from Part 1/Part 2) in `../data/`.
   `results_all_models_by_fold.csv` and `weekly_alignment_check.csv` in `../data/part2_results/`.
3. `pip install pandas numpy scipy scikit-learn matplotlib`

## Run (in this order, total < 1 minute)
    python run_part3.py        # clustering, classifier, scheduling simulation, main figures
    python ablation_part3.py   # raw vs shape profiles, k = 3/4/6/8
    python extra_analysis.py   # monthly capture, regret distribution, drift within day types

All tables go to `../outputs/`, figures to `../outputs/figures` (slides) and
`../outputs/figures_column` (IEEE report).

## Files
| File | Purpose |
|---|---|
| config.py | Paths, train/test split (train <= 2023-12-31), k range, block length, fleet size |
| data_prep.py | Load/clean target, day x hour matrix, calendar features, split |
| clustering.py | k-scan (silhouette, Davies-Bouldin, Calinski-Harabasz), k-means, Ward, cluster naming |
| daytype_forecast.py | Day-ahead day-type classifier (Random Forest) vs persistence and climatology |
| scheduling.py | 10 scheduling policies, emissions simulation, summary, paired bootstrap |
| plots.py | All Part 3 figures in two sizes |
| run_part3.py | End-to-end pipeline |
| ablation_part3.py | Representation / k ablation |
| extra_analysis.py | Monthly capture, daily regret, within-type drift, weekday vs weekend |

## Key results (test 2024-01 to 2026-10, 1,032 days, 1 MWh 4-hour daily block)
- k = 3 day types (low / mid / high carbon); k-means vs Ward ARI 0.66
- Day-type classifier accuracy 81.8% (persistence 77.6%, climatology 59.8%)
- Evening 18-22 block: 205.5 kg/MWh. Static window: -34.3%. Fixed day-type centroids: -34.0%.
  Adaptive day type: -38.4% (79 kg/MWh saved, 95% CI 76-82), 96% of the oracle saving. Oracle: -40.2%.

## Data caveat
From 2024 Q3, EIA-930 added storage categories. The shared emission-factor mapping matches
`other_energy_storage` and `unknown_energy_storage` to "other"/"unknown" (300 g/kWh) instead of 0.
Results on Jan-Jun 2024 (before the change) show the same ranking.
